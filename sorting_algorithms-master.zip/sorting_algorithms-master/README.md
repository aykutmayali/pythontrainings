Well-known sorting algorithms in Python.

Popüler sıralama algoritmaları, Python dilinde yazıldı.
